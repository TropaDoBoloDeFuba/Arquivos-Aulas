import javax.swing.*;

public class Registro {
    public static void main(String[] args) {
        JFrame Frame = new JFrame();
    }
}
